# Guardians of Velocity — App

Your exact game, packaged as an installable app.

## How to play / install

### On computer
1. Unzip this folder
2. Open `index.html` in Chrome, Edge, or Firefox
3. Play!

### On phone (install as real app)
1. Copy this folder to your phone (or host it online)
2. Open `index.html` in Chrome (Android) or Safari (iPhone)
3. Tap the browser menu → **Add to Home Screen** / **Install app**
4. It opens full-screen like a real game app

### Or just double-click
Open `index.html` — works offline after first load (service worker caches it).

Same game. Same controls. Now feels like an app.
